
		Iron Sights Mod
		  Version 1.0



INSTALLATION:

Be sure that Patch 1.4 is installed for Far Cry

Extract the IronSights folder into the "Mods" folder in your Far Cry directory.
Run Far Cry as you normally would, go to the mods section of the main menu,
and load the Iron Sights mod from there.  The game will restart, and you should
be problem free!

I also have included a shortcut in the mod folder called "Iron Sights".  If you
installed Far Cry into the default installation path on your computer, this
shortcut should work.



FEATURES:

-Gives fully functional iron sights to the Falcon, M4, Mp5, Shotgun, and M249.
-Gives a red dot sight to the P90.
-Includes option to deactivate crosshairs in the Game Options section of the main menu.
-Gives smoother transitions in and out of scopes for all scoped guns.



USE AND CREDIT:

If you would like to include this mod in another, we are fully willing to help
you with implimenting it, including providing the C++ changes if the other mod
in question also requires modification to the C++.  To find how we modified the
included lua files, simply search for "IronSights" in these files.  If you do
include this mod in another, we would greatly appreciate being credited for
anything our work contributed.





You can contact the creators on Moddb.com at:
http://www.moddb.com/mods/iron-sights


Cheerio! :)

SemiMono, Torthane, and Garcy